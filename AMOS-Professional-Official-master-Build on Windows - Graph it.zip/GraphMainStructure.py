import os
import sys
import argparse
import pyvis
import pandas as pd

from pathlib import Path
from pyvis.network import Network

def get_file_length(file):
    current_position = file.tell()    
    file.seek(0, os.SEEK_END)
    end_position = file.tell()    
    file.seek(current_position, os.SEEK_SET)
    return end_position

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Graph AMOS Pro 2.0 and Compiler main structure
#
# Written by Rolf Missing (c) 2024 under the MIT license
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

print("Graph AMOS Pro 2.0 and Compiler main structure")
print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")


#  https://memgraph.com/blog/graph-visualization-in-python
#  https://pyvis.readthedocs.io/en/latest/documentation.html
#
print(pyvis.__version__)
#
#
net = Network(notebook = True, cdn_resources = "remote",
                bgcolor = "#222222",
                font_color = "white",
                height = "750px",
                width = "100%",
)

nodes = []
edges = []


# Main components with output file definition and short description

# Location root ...\

# +AMOS_Includes.s
#    No specific output file
#    Used in:
#        +B.s 
#        +Edit.s 
#        +Lib.s
#        +Monitor.s
#        +W.s 
#        compiler\+APComp.s 
#        compiler\+CLib.s 
#        compiler\+CompExt.s 
#        compiler\+Header.s 
#        extensions\+Compact.s 
#        extensions\+IO_Ports.s 
#        extensions\+Music.s 
#        extensions\+Request.s    
#    Includes all includes - Francois Lionet / Europress 1992

#    Not a graph node or edge participent

# +B.s
#    CopyToAMIGA\AMOS_Pro\AMOSPro
#    AMOSPro Version 2 Loader general
#    AMOSPro Version 2 Loader general

net.add_node("AMOSPro", label="AMOSPro (+B.s)", title="AMOSPro Version 2 Loader general")   

# +CEqu.s
#    No specific output file    
#    Used in:
#        +AMOS_Includes.s 
#    EQUATES
#    EQUATES

#    Not a graph node or edge participent

# +Debug.s
#    No specific output file  
#    Used in:
#        +AMOS_Includes.s 
#        +Edit.s 
#        +Monitor.s 
#        +W.s    
#    No Debugging!
#    No Debugging!

#    Not a graph node or edge participent

# +Edit.s
#    CopyToAMIGA\AMOS_Pro\APSystem\AMOSPro_Editor
#    Editor Modif
#    Editor Modif

net.add_node("AMOSPro_Editor", label="AMOSPro_Editor (+Edit.s)", title="Editor Modif")   

# +Editor_Config.s
#    CopyToAMIGA\RAM\Editor_Config.o
#    DEFINITION DES MESSAGES AMOS
#    DEFINITION OF AMOS MESSAGES

net.add_node("Editor_Config.o", label="Editor_Config.o (+Editor_Config.s)", title="DEFINITION OF AMOS MESSAGES")   

# +Equ.s
#    No specific output file        
#    Used in:
#        +AMOS_Includes.s 
#        +Editor_Config.s 
#    AMOSPro EQUATES DEFINITION
#    AMOSPro EQUATES DEFINITION

#    Not a graph node or edge participent

# +ILib.s
#    No specific output file  
#    Used in:
#        +Lib.s 
#    INITIALISATION LIBRAIRIE
#    Library initialization

#    Not a graph node or edge participent

# +ILib_Functions.s
#    Ignored

#    Not a graph node or edge participent

# +ILib_Size.s
#    Ignored

#    Not a graph node or edge participent

# +Internal_Jumps.s
#    Ignored

#    Not a graph node or edge participent

# +Interpreter_Config.s
#    CopyToAMIGA\RAM\Interpreter_Config.o
#    Données de Configuration Interpreter
#    Interpreter Configuration Data

net.add_node("Interpreter_Config.o", label="Interpreter_Config.o (+Interpreter_Config.s)", title="Interpreter Configuration Data")   

# +LEqu.s
#    Ignored

#    Not a graph node or edge participent

# +Lib.s
#    CopyToAMIGA\AMOS_Pro\APSystem\AMOSPro.Lib
#    Compil'AMOS
#    Compiler AMOS

net.add_node("AMOSPro.Lib", label="AMOSPro.Lib (+Lib.s)", title="Compiler AMOS")   

# +Lib_Size.s
#    Ignored

#    Not a graph node or edge participent

# +Monitor.s
#    CopyToAMIGA\AMOS_Pro\APSystem\AMOSPro_Monitor
#    MONITOR
#    MONITOR

net.add_node("AMOSPro_Monitor", label="AMOSPro_Monitor (+Monitor.s)", title="MONITOR")   

# +Verif.s
#    No specific output file
#    Used in:
#        +B.s 
#    GESTION SOURCE CHARGEMENT / TEST / VERIF
#    SOURCE MANAGEMENT LOADING / TEST / VERIF 

#    Not a graph node or edge participent

# +Version.s
#    No specific output file
#    Used in:
#        +B.s 
#        +Edit.s (1 hit)
#        +Monitor.s (1 hit)
#        compiler\+APComp.s (1 hit)
#        compiler\+CLib.s (1 hit)
#        compiler\+CompExt.s (1 hit)
#        extensions\+Compact.s (1 hit)
#        extensions\+IO_Ports.s (1 hit)
#        extensions\+Music.s (1 hit)
#        extensions\+Request.s (1 hit)

#    Not a graph node or edge participent

# +W.s
#    AMOS/APSystem/AMOS.library
#    LIBRAIRIE GRAPHIQUE AMOS
#    AMOS GRAPHIC LIBRARY 

net.add_node("AMOS.library", label="AMOS.library (+W.s)", title="AMOS GRAPHIC LIBRARY")   

# +WEqu.s
#    No specific output file
#    Used in:
#        +AMOS_Includes.s 
#    EQUATES GRAPHIC FUNCTIONS AMOS
#    EQUATES GRAPHIC FUNCTIONS AMOS

#    Not a graph node or edge participent
   	
# Location ...\compiler

# +APComp.s
#    CopyToAMIGA\AMOS_Pro\APSystem\APCmp
#    AMOSPro Compiler 

net.add_node("APCmp", label="APCmp (+APComp.s)", title="AMOSPro Compiler")   

# +CLib.s
#    CopyToAMIGA\AMOS_Pro\APSystem\Compiler.Lib
#    AMOSPro Compiler Internal library

net.add_node("Compiler.Lib", label="Compiler.Lib (+CLib.s)", title="AMOSPro Compiler Internal library")   

# +CLib_Labels.s
#    Ignored

#    Not a graph node or edge participent

# +CLib_Size.s
#    Ignored

#    Not a graph node or edge participent

# +CompExt.s
#    CopyToAMIGA\AMOS_Pro\APSystem\AMOSPro_Compiler.Lib
#    AMOS Compiler Extension For AMOSPro 2.0 and over 

net.add_node("AMOSPro_Compiler.Lib", label="AMOSPro_Compiler.Lib (+CompExt.s)", title="AMOS Compiler Extension For AMOSPro 2.0 and over")   

# +Compext_Labels.s
#    Ignored

#    Not a graph node or edge participent

# +Compext_Size.s
#    Ignored

#    Not a graph node or edge participent

# +Compiler_Config.s
#    CopyToAMIGA\RAM\Compiler_Config.o
#    Données de Configuration Interpreter
#    Interpreter Configuration Data

net.add_node("Compiler_Config.o", label="Compiler_Config.o (+Compiler_Config.s)", title="Interpreter Configuration Data")   

# +Header.s
#    CopyToAMIGA\AMOS_Pro\APSystem\Header_CLI.Lib
#    Entete programme objet
#    Program object header

net.add_node("Header_CLI.Lib", label="Header_CLI.Lib (+Header.s)", title="Program object header")   

# +Header_Backstart.s
#    CopyToAMIGA\AMOS_Pro\APSystem\Header_Backstart.Lib
#    HEADER BACKSTART Programme compile
#    HEADER BACKSTART Program compiles

net.add_node("Header_Backstart.Lib", label="Header_Backstart.Lib (+Header_Backstart.s)", title="HEADER BACKSTART Program compiles")   

# Location ...\extensions

# +Compact.s
#    CopyToAMIGA\AMOS_Pro\APSystem\AMOSPro_Compact.Lib 
#    AMOSPro Picture compactor extension 

net.add_node("AMOSPro_Compact.Lib", label="AMOSPro_Compact.Lib (+Compact.s)", title="AMOSPro Picture compactor extension")   

# +Compact_Labels.s
#    Ignored

#    Not a graph node or edge participent

# +Compact_Size.s
#    Ignored

#    Not a graph node or edge participent

# +IO_Ports.s
#    CopyToAMIGA\AMOS_Pro\APSystem\AMOSPro_IOPorts.Lib
#    Serial / Parallel / Printer extension 

net.add_node("AMOSPro_IOPorts.Lib", label="AMOSPro_IOPorts.Lib (+IO_Ports.s)", title="Serial / Parallel / Printer extension")   

# +IO_Ports_Labels.s
#    Ignored

#    Not a graph node or edge participent

# +IO_Ports_Size.s
#    Ignored

#    Not a graph node or edge participent

# +Music.s
#    CopyToAMIGA\AMOS_Pro\APSystem\AMOSPro_Music.Lib
#    Music extension 

net.add_node("AMOSPro_Music.Lib", label="AMOSPro_Music.Lib (+Music.s)", title="Music extension")   

# +Music_Labels.s
#    Ignored

#    Not a graph node or edge participent

# +Music_Size.s
#    Ignored

#    Not a graph node or edge participent

# +Request.s
#    CopyToAMIGA\AMOS_Pro\APSystem\AMOSPro_Request.Lib
#    AMOS Requester handler

net.add_node("AMOSPro_Request.Lib", label="AMOSPro_Request.Lib (+Request.s)", title="AMOS Requester handler")   

# +Request_Labels.s
#    Ignored

#    Not a graph node or edge participent

# +Request_Size.s
#    Ignored

#    Not a graph node or edge participent
    

# Main components with file references    
    
# Location root ...\

# +B.s
#    +AMOS_Includes.s
#		exec_lib.i
#		dos_lib.i
#		layers_lib.i
#		graphics_lib.i
#		mathtrans_lib.i
#		rexxsyslib_lib.i
#		mathffp_lib.i
#		mathieeedoubbas_lib.i
#		intuition_lib.i
#		diskfont_lib.i
#		icon_lib.i
#		console_lib.i
#		+Debug.s
#		+Equ.s
#		+CEqu.s
#		+WEqu.s
#		+LEqu.s
#		+Music_Labels.s
#    +Verif.s
#    +Version.s

net.add_node("+AMOS_Includes.s", label="+AMOS_Includes.s", title="Includes all includes")   
edges.append(["AMOSPro", "+AMOS_Includes.s"])

net.add_node("exec_lib.i", label="exec_lib.i", title="Exec library")   
edges.append(["+AMOS_Includes.s", "exec_lib.i"])

net.add_node("dos_lib.i", label="dos_lib.i", title="DOS library ")   
edges.append(["+AMOS_Includes.s", "dos_lib.i"])

net.add_node("layers_lib.i", label="layers_lib.i", title="Layers library")   
edges.append(["+AMOS_Includes.s", "layers_lib.i"])

net.add_node("graphics_lib.i", label="graphics_lib.i", title="Graphics library")   
edges.append(["+AMOS_Includes.s", "graphics_lib.i"])

net.add_node("mathtrans_lib.i", label="mathtrans_lib.i", title="Mathtrans library")   
edges.append(["+AMOS_Includes.s", "mathtrans_lib.i"])

net.add_node("rexxsyslib_lib.i", label="rexxsyslib_lib.i", title="Rexxsyslib library")   
edges.append(["+AMOS_Includes.s", "rexxsyslib_lib.i"])

net.add_node("mathffp_lib.i", label="mathffp_lib.i", title="Mathffp library")   
edges.append(["+AMOS_Includes.s", "mathffp_lib.i"])

net.add_node("mathieeedoubbas_lib.i", label="mathieeedoubbas_lib.i", title="Mathieeedoubbas library")   
edges.append(["+AMOS_Includes.s", "mathieeedoubbas_lib.i"])

net.add_node("intuition_lib.i", label="intuition_lib.i", title="Intuition library")   
edges.append(["+AMOS_Includes.s", "intuition_lib.i"])

net.add_node("diskfont_lib.i", label="diskfont_lib.i", title="Diskfont library")   
edges.append(["+AMOS_Includes.s", "diskfont_lib.i"])

net.add_node("icon_lib.i", label="icon_lib.i", title="Icon library")   
edges.append(["+AMOS_Includes.s", "icon_lib.i"])

net.add_node("console_lib.i", label="console_lib.i", title="Console library")   
edges.append(["+AMOS_Includes.s", "console_lib.i"])

net.add_node("+Debug.s", label="+Debug.s", title="Debug mode")
edges.append(["+AMOS_Includes.s", "+Debug.s"])

net.add_node("+Equ.s", label="+Equ.s", title="AMOSPro equates")   
edges.append(["+AMOS_Includes.s", "+Equ.s"])

net.add_node("+CEqu.s", label="+CEqu.s", title="Compiler equates")   
edges.append(["+AMOS_Includes.s", "+CEqu.s"])

net.add_node("+WEqu.s", label="+WEqu.s", title="AMOS graphic functions equates")   
edges.append(["+AMOS_Includes.s", "+WEqu.s"])

net.add_node("+LEqu.s", label="+LEqu.s", title="AMOS library functions equates")   
edges.append(["+AMOS_Includes.s", "+LEqu.s"])

net.add_node("+Music_Labels.s", label="+Music_Labels.s", title="Music library functions")   
edges.append(["+AMOS_Includes.s", "+Music_Labels.s"])

net.add_node("+Verif.s", label="+Verif.s", title="Source management loading / test / verif")   
edges.append(["AMOSPro", "+Verif.s"])

net.add_node("+Version.s", label="+Version.s", title="Version")   
edges.append(["AMOSPro", "+Version.s"])

# +Edit.s
#    +Debug.s
#    +AMOS_Includes.s
#    +Version.s

edges.append(["AMOSPro_Editor", "+Debug.s"])
edges.append(["AMOSPro_Editor", "+AMOS_Includes.s"])
edges.append(["AMOSPro_Editor", "+Version.s"])

# +Editor_Config.s
#      +Equ.s

edges.append(["Editor_Config.o", "+Equ.s"])

# +Interpreter_Config.s

# Already registered in graph

# +Lib.s
#    +AMOS_Includes.s
#    +ILib.s

edges.append(["AMOSPro.Lib", "+AMOS_Includes.s"])

net.add_node("+ILib.s", label="+ILib.s", title="Library initialization")   
edges.append(["AMOSPro.Lib", "+ILib.s"])

# +Monitor.s
#    +Debug.s
#    +AMOS_Includes.s
#    +Version.s

edges.append(["AMOSPro_Monitor", "+Debug.s"])
edges.append(["AMOSPro_Monitor", "+AMOS_Includes.s"])
edges.append(["AMOSPro_Monitor", "+Version.s"])

# +W.s
#    +Debug.s
#    +AMOS_Includes.s

edges.append(["AMOS.library", "+Debug.s"])
edges.append(["AMOS.library", "+AMOS_Includes.s"])

# Location ...\compiler

# +APComp.s
#    +AMOS_Includes.s
#    +Version.s

edges.append(["APCmp", "+AMOS_Includes.s"])
edges.append(["APCmp", "+Version.s"])

# +CLib.s
#    +AMOS_Includes.s
#    +Version.s

edges.append(["Compiler.Lib", "+AMOS_Includes.s"])
edges.append(["Compiler.Lib", "+Version.s"])

# +CompExt.s
#    +AMOS_Includes.s
#    +Version.s

edges.append(["AMOSPro_Compiler.Lib", "+AMOS_Includes.s"])
edges.append(["AMOSPro_Compiler.Lib", "+Version.s"])

# +Compiler_Config.s

# Already registered in graph

# +Header.s
#    +AMOS_Includes.s

edges.append(["Header_CLI.Lib", "+AMOS_Includes.s"])

# +Header_Backstart.s

# Already registered in graph

# Location ...\extensions

# +Compact.s
#    +AMOS_Includes.s
#    +Version.s

edges.append(["AMOSPro_Compact.Lib", "+AMOS_Includes.s"])
edges.append(["AMOSPro_Compact.Lib", "+Version.s"])

# +IO_Ports.s
#    +AMOS_Includes.s
#    +Version.s

edges.append(["AMOSPro_IOPorts.Lib", "+AMOS_Includes.s"])
edges.append(["AMOSPro_IOPorts.Lib", "+Version.s"])

# +Music.s
#    +AMOS_Includes.s
#    +Version.s

edges.append(["AMOSPro_Music.Lib", "+AMOS_Includes.s"])
edges.append(["AMOSPro_Music.Lib", "+Version.s"])

# +Request.s
#    +AMOS_Includes.s
#    +Version.s

edges.append(["AMOSPro_Request.Lib", "+AMOS_Includes.s"])
edges.append(["AMOSPro_Request.Lib", "+Version.s"])

net.add_nodes(nodes)

net.add_edges(edges)

net.show("AMOS Pro 2.0 and Compiler - Graph main structure.html")









