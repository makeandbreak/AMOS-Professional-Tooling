import os
import sys
import argparse
import pyvis
import pandas as pd

from pathlib import Path
from pyvis.network import Network

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Graph Devpac assembler
#
# Written by Rolf Missing (c) 2024 under the MIT license
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

print("Graph Devpac assembler")
print("~~~~~~~~~~~~~~~~~~~~~~")

# Check command line arguments

parser = argparse.ArgumentParser("GraphDevpacAssembler.py")
parser.add_argument("product_name", help="Name of product graph is for.", type=str)
parser.add_argument("component_name", help="Name of component being graphed.", type=str)
parser.add_argument("src_file_name", help="Name of src file to graph.", type=str)

args = parser.parse_args()

#  https://memgraph.com/blog/graph-visualization-in-python
#
print("pyvis version used: "+pyvis.__version__)
#
#
net = Network(notebook = True, cdn_resources = "remote",
                bgcolor = "#222222",
                font_color = "white",
                height = "750px",
                width = "100%",
)

nodes = []
edges = []

# Load the src file
# ~~~~~~~~~~~~~~~~~

src_file_name = Path(args.src_file_name)

if not src_file_name.is_file():
    print("Can not access '"+args.src_file_name+"'")
    exit()
    
print("Loading '"+args.src_file_name+"'...")

input_file = open(args.src_file_name, "r")

src_file_content_lines = input_file.readlines()

src_file_size_lines = len(src_file_content_lines)

print("Loaded "+str(src_file_size_lines)+" lines.")

input_file.close()

# Activate diagnostics 

diagnostics_active=False
diagnostics_print_all_lines=False

# Setup looking for a specific name

diagnostics_looking_for_name = ""

# Initialize block name

current_block_name = ""

# Initialize MACRO sections ignore

ignoring_macro=False
macro_name=""

# Operands extracted (including those defined using a MACRO)

operands_extracted = []
operands_extracted.append("beq") # Covers beq.b beq.s beq.l
operands_extracted.append("jmp")
operands_extracted.append("jsr")
operands_extracted.append("bpl")
operands_extracted.append("bra")
operands_extracted.append("bne")
operands_extracted.append("ble")
operands_extracted.append("JJsrP")
operands_extracted.append("JJsr")
operands_extracted.append("JJsrR")
operands_extracted.append("bcc")
operands_extracted.append("blt")
operands_extracted.append("bge")
operands_extracted.append("bls")
operands_extracted.append("bhi")
operands_extracted.append("bmi")
operands_extracted.append("bcs")
operands_extracted.append("bsr")
operands_extracted.append("DosCall")
operands_extracted.append("SyCall")
operands_extracted.append("Ijsr")
operands_extracted.append("Rbra")
operands_extracted.append("Rjsr")
operands_extracted.append("Rbmi")
operands_extracted.append("Rbne")
operands_extracted.append("Rjsrt")
operands_extracted.append("Rjmpt")
operands_extracted.append("Rbsr")
operands_extracted.append("Rjmp")
operands_extracted.append("Rble")
operands_extracted.append("Rbge")
operands_extracted.append("WiCalA")
operands_extracted.append("WiCalD")
operands_extracted.append("Lib_Def")
operands_extracted.append("dbra")

operands_no_join_block = []

operands_no_join_block.append("jmp")
operands_no_join_block.append("rts")
operands_no_join_block.append("Rjmp")

no_join_block=False

for line_number in range(0,src_file_size_lines):

    current_line_content = src_file_content_lines[line_number][:-1]
    
    if (diagnostics_active==True) and \
       (diagnostics_print_all_lines==True):
        print("Line: "+str(line_number)+" ->"+current_line_content)
        
    # Strip spaces    
    current_line_content = current_line_content
        
    # Skip empty lines
    if len(current_line_content) == 0:
        continue 

    # Skip lines that start with a comment line indicator '*', ';' or a '!'
    if current_line_content[0] in "*;!":
        continue 

    # Skip lines that contain 'dc.'
    if current_line_content.find("dc.") > -1:
        continue 
    
    # Skip lines that contain 'ds.'
    if current_line_content.find("ds.") > -1:
        continue 

    # Skip lines that contain 'equ'
    if current_line_content.find("equ") > -1:
        continue 

    # Skip lines that contain 'rs.'
    if current_line_content.find("rs.") > -1:
        continue 
        
    # Skip lines that contain 'Include'
    if current_line_content.find("Include") > -1:
        continue 
    
    # Skip lines that contain 'IncDir'
    if current_line_content.find("IncDir") > -1:
        continue 
           
    # Skip lines that contain 'OPT'
    if current_line_content.find("OPT") > -1:
        continue 

        
    # Insure split does not file on cases similar to this:
    #     trsmm3b:movem.l	(sp)+,a0/a1 ;pointe la fin des zones    
    # but do not fail on these:
    #     move.b	#":",(a0)+
    # "@" is not used in lines containing target operands
    
    if current_line_content.find(":") > -1:
        current_line_content = current_line_content.replace('":"','"@"')
        current_line_content = current_line_content.replace(":"," ")
        current_line_content = current_line_content.replace('"@"', '":"')
        
    # Prevent split failure
    #   Fft1:	move.b	#" ",(a0)+
    current_line_content = current_line_content.replace('" "','"@"')

    # Split current line
    
    current_line_content_split = current_line_content.split()
    
    current_line_content_split_count = len(current_line_content_split)

    # Prevent split failure (restore string)
    
    for index in range(0,current_line_content_split_count):
        if current_line_content_split[index].find('"@"'):
            current_line_content_split[index].replace('"@"', '" "')
            break
 
    if (diagnostics_active==True) and \
       (diagnostics_print_all_lines==True):
        print("current_line_content_split_count: "+str(current_line_content_split_count))
        print("current_line_content_split: ", current_line_content_split)

    # Ignore MAKRO blocks similar to this:
    #    Tjsr	MACRO
    #	          jsr	\1
    #	          move.l	Mon_Base(a5),a4
    #	        ENDM        
    if (current_line_content_split_count == 2) and \
        (current_line_content.find("MACRO") > -1):
          
        macro_name=current_line_content_split[0]
          
        if diagnostics_active==True:
            print("Start ignoring macro:Name->"+macro_name)
                
        ignoring_macro=True 
             
        continue

    if (current_line_content_split_count == 1) and \
        (current_line_content.find("ENDM") > -1):
          
        if diagnostics_active==True:
            print("Stop ignoring macro:Name->"+macro_name)
                
        ignoring_macro=False 
             
        continue
        
    if ignoring_macro==True:
        continue  
        
    # Line with a word starting in column 0
    # This is considered the current block name
    if (current_line_content[0] != " ") and \
        (current_line_content[0] != "\t"):      
        
        old_block_name = current_block_name         
        
        current_block_name = current_line_content_split[0]
            
        if diagnostics_active==True:
            print("Saving block name->"+current_block_name+"<-")
            
        nodes.append(current_block_name)
            
        if (no_join_block == False) and \
            (old_block_name != ""):
            edges.append([old_block_name, current_block_name])
        elif no_join_block == True:
            no_join_block = False   
            
        if (diagnostics_active==True) and \
            (current_block_name == diagnostics_looking_for_name):
            sys.exit()
                
    # Handle cases these examles and more
    #    ->        beq.s   .Clin1<-    
    #    ->        jmp     Get_Out<-
    #    ->        jsr     _LVOCloseLibrary(a6)<-
    #    ->        jsr     -384(a6)                WaitPort<-
    #    ->.Skip	jsr	_LVOCacheClearU(a6)		CacheClearU <-
    #    ->        bpl.s   .Loop1<-
    #    ->        bra     Ll_Mess                 Oui,<- 
    #    ->Ll_Mess bra     Ll_BadExt               Illegal<-
    #    ->JFonc:	bra	Ed_CHaut		* 1  Cur Haut<-
    #    ->        bne     TheEnd_Editor                   Tant pis!<- 
    #    ->        DosCall _LVOLock<-
    #    -> 	JJsrR	L_FloatToAsc,a1<-
    #    ->	JJsrR	L_Tk_EditL,a1		Peut on couper la ligne?<-
    #    ->FnAt4:	Rbra	L_FinBin<-
    #    ->	Rjmp	L_Bnk.Change<- 
    #    ->	WiCalA	Print,Fs_COff(pc)<- 
    #    etc
        
    # Position of entities in split line

    position_label = -1
    
    position_operand = -1

    position_operand_argument = -1

    position_comment_start = -1   # May be split into several parts

    # Find location if any of the supported operand
    
    position_operand = -1
    
    if diagnostics_active == True:
        print("Line input:"+current_line_content)
    
    for index in range(0,current_line_content_split_count):
        
        operand_clean = current_line_content_split[index].strip()
               
        if diagnostics_active == True:
            print("Line input split at "+str(index)+":"+current_line_content_split[index].strip())
               
        if len(operand_clean) > 2:
            if operand_clean[len(operand_clean)-2:] == ".b":
                operand_clean = operand_clean.replace(".b","")
            if operand_clean[len(operand_clean)-2:] == ".s":
                operand_clean = operand_clean.replace(".s","")
            if operand_clean[len(operand_clean)-2:] == ".l":
                operand_clean = operand_clean.replace(".l","")
                        
        if diagnostics_active == True:
            print("operand_clean: ->"+operand_clean+"<-") 
            
        if operand_clean in operands_no_join_block:
            no_join_block=True
            
        if operand_clean in operands_extracted:
            position_operand = index
            break
    
    if position_operand == -1:
        continue
        
    if position_operand == 0:        
        position_operand_argument = 1
        
        if current_line_content_split_count > 2:
            position_comment_start = 2
            
    if position_operand == 1:        
        position_label = 0
        position_operand_argument = 2
        
        if current_line_content_split_count > 3:
            position_comment_start = 3
    
    # Clean and save label 
    # Note: Labels that start with '.' are often considered local and probably
    #       shouöd be ignored. However in the codebase I targeted this convention
    #       was often not respected so we process all labels.    
    
    if position_label > 0:
        
        label = current_line_content_split[position_label].strip()
        
        #if not label in nodes:
        if not label.upper() in map(str.upper, nodes):         
         
            if diagnostics_active == True:
                print("Saving target label->"+label+"<-")
            
            nodes.append(label)                        
 
        if (diagnostics_active == True) and \
           (label == diagnostics_looking_for_name):
            sys.exit()

    if position_operand_argument > -1:
                
        operand_argument = current_line_content_split[position_operand_argument].strip()
        
        if diagnostics_active == True:
            print("operand_argument->"+operand_argument+"<-")
         
        operand_argument_cleaned=operand_argument.replace("(a6)","")

        operand_argument_cleaned=operand_argument_cleaned.replace("(a0,d0.w)","")

        operand_argument_cleaned=operand_argument_cleaned.replace("-$10e","WaitTOF")
                
        operand_argument_cleaned=operand_argument_cleaned.replace("-$de","LoadView")

        operand_argument_cleaned=operand_argument_cleaned.replace("-$27c","CacheClearU")

        operand_argument_cleaned=operand_argument_cleaned.replace("-$30","RawKeyConvert")
                           
        operand_argument_cleaned=operand_argument_cleaned.replace("(pc,d0.l)","")           
                                                                                        
        operand_argument_cleaned=operand_argument_cleaned.replace("(a0)","")
                                
        operand_argument_cleaned=operand_argument_cleaned.replace("(a0,d1.w)","")
                               
        operand_argument_cleaned=operand_argument_cleaned.replace("-$10e","WaitTOF")
                
        operand_argument_cleaned=operand_argument_cleaned.replace("-$de","LoadView")
                
        operand_argument_cleaned=operand_argument_cleaned.replace(",a1","")
        operand_argument_cleaned=operand_argument_cleaned.replace(",a2","")

        operand_argument_cleaned=operand_argument_cleaned.replace("(pc)","")
        
        operand_argument_cleaned=operand_argument_cleaned.replace("d0,","")
        operand_argument_cleaned=operand_argument_cleaned.replace("d1,","")
        operand_argument_cleaned=operand_argument_cleaned.replace("d2,","")
        operand_argument_cleaned=operand_argument_cleaned.replace("d3,","")
        operand_argument_cleaned=operand_argument_cleaned.replace("d4,","")
        operand_argument_cleaned=operand_argument_cleaned.replace("d5,","")
        operand_argument_cleaned=operand_argument_cleaned.replace("d6,","")
        operand_argument_cleaned=operand_argument_cleaned.replace("d7,","")
        
        operand_argument_cleaned=operand_argument_cleaned.replace("-$270","CallOffset-$270")
        operand_argument_cleaned=operand_argument_cleaned.replace("-$216","CallOffset-$216")                       
        operand_argument_cleaned=operand_argument_cleaned.replace("-$276","CallOffset-$276")
     
        if operand_argument_cleaned == '':
            operand_argument_cleaned = "CallVia_a6"
                
        if operand_argument_cleaned[0] == '-': 
            if int(operand_argument_cleaned) < 0:
            
                #-90

                if int(operand_argument_cleaned) == -90:
                    operand_argument_cleaned = "_LVOMakeFunctions"
                
                #-378

                elif int(operand_argument_cleaned) == -378:
                    operand_argument_cleaned = "_LVOReplyMsg"

                #-60
                
                elif int(operand_argument_cleaned) == -60:
                    operand_argument_cleaned = "_LVOUnLock"

                #-348

                elif int(operand_argument_cleaned) == -348:
                    operand_argument_cleaned = "_LVOFreeTrap"

                #-270

                elif int(operand_argument_cleaned) == -270:
                    operand_argument_cleaned = "_LVOEnqueue"

                #-384		

                elif int(operand_argument_cleaned) == -384:
                    operand_argument_cleaned = "_LVOWaitPort"

                #-372		

                elif int(operand_argument_cleaned) == -372:
                    operand_argument_cleaned = "_LVOGetMsg"

                #-78		

                elif int(operand_argument_cleaned) == -78:
                    operand_argument_cleaned = "_LVOInitStruct"

                #-222
                              
                elif int(operand_argument_cleaned) == -222:
                    operand_argument_cleaned = "_LVOAllocEntry"

        if operand_argument_cleaned[0] == '-': 
            operand_argument_cleaned = "CallOffset" + operand_argument_cleaned

        if operand_argument_cleaned == "0": 
            operand_argument_cleaned = "CallOffset0"

        if operand_argument_cleaned == "2": 
            operand_argument_cleaned = "CallOffset2"

        if operand_argument_cleaned == "4": 
            operand_argument_cleaned = "CallOffset4"
            
        if operand_argument_cleaned == "8": 
            operand_argument_cleaned = "CallOffset8"

        if operand_argument_cleaned == "16": 
            operand_argument_cleaned = "CallOffset16"
             
        if diagnostics_active == True:     
            print("Using operand_argument_cleaned->"+operand_argument_cleaned+"<- in block:"+current_block_name)

        #if not operand_argument_cleaned in nodes:
        if not operand_argument_cleaned.upper() in map(str.upper, nodes):    
           nodes.append(operand_argument_cleaned)
           if diagnostics_active == True:
               print("Node name added:"+operand_argument_cleaned)
           
        #Ensure operand_argument_cleaned is unique node identifier (case insensetive)   
        if not operand_argument_cleaned in nodes:
            
            if diagnostics_active == True:
                print("operand_argument_cleaned 1:"+operand_argument_cleaned)
            
            if operand_argument_cleaned.upper() in map(str.upper, nodes):

                if diagnostics_active == True:
                    print("operand_argument_cleaned 2:"+operand_argument_cleaned.upper())
                
                for index in range(0, len(nodes)):
                    if operand_argument_cleaned.upper() == nodes[index].upper():
                        operand_argument_cleaned=nodes[index]
                        
                        if diagnostics_active == True:
                            print("operand_argument_cleaned 3:"+operand_argument_cleaned)
                        
                        break
                
        # We have a case where there is no block name at the start of the
        # code file. This is indicative of a generic entry point so we
        # will assign it the name 'Entry'.          
        if current_block_name=="":
            nodes.append("Entry")              
            current_block_name="Entry"
            
        edges.append([operand_argument_cleaned, current_block_name])

        if (diagnostics_active == True) and \
            (operand_argument_cleaned == diagnostics_looking_for_name):
            CRASH()
            sys.exit()
            
        if (diagnostics_active == True) and \
            (current_block_name == diagnostics_looking_for_name):
            CRASH()    
            sys.exit()
            
net.add_nodes(nodes)

if diagnostics_active == True:
    print(edges)

net.add_edges(edges)

net.show(args.product_name+" "+args.component_name+" ("+os.path.basename(args.src_file_name)+").html")

print()

sys.exit()