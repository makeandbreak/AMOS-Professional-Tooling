		Include "+AMOS_Includes.s"
		Include "+Version.s"

; - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
; 	ROUTINES DE FIN / ROUTINES INTERNES
;   END ROUTINES / INTERNAL ROUTINES
; - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
	SECTION	"E",CODE
; - - - - - - - - - - - - -
; Line 64
Hunk_1	jmp	Cold_Start

;Added: We ignore code here for now
nop

; Sortie d'AMOSPro!
; AMOSPro Released!
; ~~~~~~~~~~~~~~~~~
Get_Out	

; Restore stack address
    move.l	SaveSp(pc),a7

; Message provided?	
	tst.l	d7
	beq.s	.PaMe
	
; forbid task rescheduling	
	move.l	SP_ExecBase(sp),a6

; _LVOForbid()
;   Library name: Forbid 
;   Short description: Forbid task rescheduling
;   C-declaration: void Forbid(void); 
;   Assembler register usage: NA   
;   Input clarifications: NA
;   Struct details of interest: NA
;   Results: NA
;   Further details: http://amigadev.elowar.com/read/ADCD_2.1/Includes_and_Autodocs_2._guide/node0353.html	
	jsr	_LVOForbid(a6)

	move.l 	d7,a1

; _LVOReplyMsg()
;   Library name: ReplyMsg 
;   Short description: Put a message to its reply port
;   C-declaration: void ReplyMsg(struct Message *); 
;   Assembler register usage: ReplyMsg(message)
;                                        A1  
;   Input clarifications: NA
;   Struct 'Message' details of interest: NA (for this analysis)
;   Results: NA
;   Further details: http://amigadev.elowar.com/read/ADCD_2.1/Includes_and_Autodocs_2._guide/node0379.html	
	jsr	_LVOReplyMsg(a6)

.PaMe	
; Return code
    moveq	#0,d0
	rts


; Imprime le message d'erreur dans l'entree courante
; Prints the error message to the current input
; ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
;	A3=	DosBase
;	A4=	IntBase
;	D7=	Message
Panic_Message
; Check there is a message
	move.l	Panic(pc),d6		Un message? / A message?
	beq.s	.Exit
; Workbench?
	tst.l	d7			Sous WB? / Under WB?
	bne.s	.Wb
; Sous DOS-> Message dans la fenetre courante
; Under DOS-> Message in current window
	move.l	a3,a6			Handle courant / Current handle
	
; Get initial output file handle

; _LVOOutput()
;   Library name: Output 
;   Short description: Identify the program's initial output file handle
;   C-declaration: BPTR Output(void) 
;   Assembler register usage: file = Output()
;                              D0      
;   Input clarifications: NA
;   Struct details of interest: NA 
;   Results: file - BCPL pointer to a file handle
;   Further details: http://amigadev.elowar.com/read/ADCD_2.1/Includes_and_Autodocs_2._guide/node02D8.html
	jsr	_LVOOutput(a6)

	move.l	d0,d1
	
; Leave if no handle available	
	beq.s	.Exit
; Move sp to work buffer	
	lea	-128(sp),sp		Buffer de travail / Work buffer
	
; Copy message referenced by d6 to work buffer	

	move.l	sp,d2
	move.l	d6,a0
	move.l	d2,a1
	
.Copy
	
    move.b	(a0)+,(a1)+
	bne.s	.Copy

; Add carrage return
	
	move.b	#10,-1(a1)

; Null terminate

	clr.b	(a1)

; Calculate length
	move.l	a1,d3
	sub.l	d2,d3

; _LVOWrite()
;   Library name: Write 
;   Short description: Write bytes of data to a file
;   C-declaration: LONG Write (BPTR, void *, LONG) 
;   Assembler register usage: returnedLength =  Write( file, buffer, length )
;                                    D0                  D1    D2      D3    
;   Input clarifications:
;      file - BCPL pointer to a file handle
;      buffer - pointer to the buffer
;      length - integer
;   Struct details of interest: NA 
;   Results: returnedLength - integer
;   Further details: http://amigadev.elowar.com/read/ADCD_2.1/Includes_and_Autodocs_2._guide/node0310.html
	jsr	_LVOWrite(a6)
	
; Restore stack pointer
	
	lea	128(sp),sp
	
.Exit	rts

; Sous WB-> ouvre une tchote fenetre
; Under WB-> open a chat window
.Wb	

	move.l	a4,a6			IntBase
	
; Build a autorequester definition
; Related data structure below "Definition of the little requester" 
	
	lea	H_Click(pc),a0
	lea	H_AutoBody(pc),a1
	move.l	d6,12(a1)
	lea	H_AutoClick(pc),a3
	move.l	a0,12(a3)
	sub.l	a2,a2
	sub.l	a0,a0
	moveq	#0,d0
	moveq	#0,d1
	move.l	#560,d2
	moveq	#50,d3
	
; Initiate autorequester	

; _LVOAutoRequest()
;   Library name: AutoRequest 
;   Short description: Automatically build and get response from a requester
;   C-declaration: BOOL AutoRequest( struct Window *, struct IntuiText *,
;                                    struct IntuiText *, struct IntuiText *,
;                                    ULONG, ULONG, WORD, WORD ); 
;   Assembler register usage: Response = AutoRequest( Window, BodyText, PosText, NegText,
;                                D0                      A0      A1        A2       A3
;	                                                  PosFlags, NegFlags, Width, Height )
;	                                                     D0        D1       D2     D3
;   Input clarifications: Window = pointer to a Window structure
;		                  BodyText = pointer to an IntuiText structure
;		                  PosText = pointer to an IntuiText structure, may by NULL.
;		                  NegText = pointer to an IntuiText structure, MUST be valid!
;		                  PosFlags = flags for the IDCMP
;		                  NegFlags = flags for the IDCMP
;		                  Width, Height = the sizes to be used for the rendering of the requester
;   Struct details of interest: NA 
;   Results: The return value is either TRUE or FALSE
;   Further details: http://amigadev.elowar.com/read/ADCD_2.1/Includes_and_Autodocs_2._guide/node01FF.html
	jsr	_LVOAutoRequest(a6)
	
	bra.s	.Exit

; Definition du petit requester
; Definition of the little requester
; ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
H_AutoBody	dc.b	2,0
		dc.w	1
		dc.w	8,7
		dc.l	0
		dc.l	0
		dc.l	0
H_AutoClick	dc.b	0,1
		dc.w	1
		dc.w	5,4
		dc.l	0
		dc.l	0
		dc.l	0
H_Click		dc.b	" Cancel ",0
		even


; Ne pas changer la position du nom, apres dos.library!
; Do not change the position of the name, after dos.library!
; ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		even
DosName		dc.b 	"dos.library",0
;ADDED START: Say hello
msg             dc.b    "Command line processed and we exit",$0a
;ADDED END




;		Noms des Librairies
;       Names of libraries 
; ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
; Line 377
SaveSp		dc.l 	0
Panic		dc.l	0
;ADDED START
; Constants
_AbsExecBase    equ   $4

; Structure field offsets

; Structure AppMessage  
; Offset to field am_ArgList Pointer to WBArg
am_ArgList      equ   $22    
; Structure Process 
; Offset to field pr_CLI Pointer to CommandLineInterface
pr_CLI          equ   $ac	 
;ADDED END

; Buffer dans la pile pour debuter
; Buffer into the stack to start
; ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
; Line 1435
		RsReset
SP_Message	rs.l	1
SP_AutoLock	rs.l	1
SP_AutoName	rs.b	128
SP_Config	rs.b	128
SP_DefSize	rs.l	1
SP_DosBase	rs.l	1
SP_IntBase	rs.l	1
SP_Command	rs.l	2		
SP_WSegment	rs.l	1
SP_WBench	rs.w	1
SP_CommandLine	rs.l	1
;ADDED START: To remove hard coded ExecBase
SP_ExecBase rs.l    1
;ADDED END
SP_Buffer	equ	__RS


; - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
; 	DEMARRAGE A FROID
;   COLD START
; - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
; Line 1453
Hunk_2
Cold_Start
; - - - - - - - - - - - - -

	move.l	sp,SaveSp

; Reserve un buffer dans la pile, pour travailler
; Reserve a buffer in the stack, to work on
; ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	lea	-SP_Buffer(sp),sp
	movem.l	a0/d0,SP_Command(sp)

;ADDED START: To remove hard coded ExecBase
;    move.l	$4.w,a6
;    ..\amigadevelopercdv2.1\NDK\NDK_2.0\NDK2.0-4\INCLUDE\EXEC\EXECBASE.H
;         Definition of the Exec library base structure (pointed to by location 4).
;         struct ExecBase {...
    
; Init ExecBase
; ~~~~~~~~~~~~~~~~
	move.l _AbsExecBase,a6
    move.l  (a6),SP_ExecBase(sp)
;ADDED END

; Init dos.library
; ~~~~~~~~~~~~~~~~
	moveq	#0,d0
	lea	DosName,a1
	move.l	SP_ExecBase(sp),a6

; _LVOOpenLibrary()
;   Library name: OpenLibrary 
;   Short description: Gain access to a library
;   C-declaration: struct Library *OpenLibrary(STRPTR, ULONG);  
;   Assembler register usage: library = OpenLibrary(libName, version)
;                               D0                    A1       D0   
;   Input clarifications: NA
;   Struct details of interest: NA 
;   Results: library - a library pointer for a successful open, else zero
;   Further details: http://amigadev.elowar.com/read/ADCD_2.1/Includes_and_Autodocs_2._guide/node0367.html	
	jsr	_LVOOpenLibrary(a6)

	move.l	d0,SP_DosBase(sp)

; Init INTUITION library
; ~~~~~~~~~~~~~~~~~~~~~~
	move.l	SP_ExecBase(sp),a6
	moveq	#0,d0
	move.l	d0,d3
	lea	IntName(pc),a1

; _LVOOpenLibrary()
;   Library name: OpenLibrary 
;   Short description: Gain access to a library
;   C-declaration: struct Library *OpenLibrary(STRPTR, ULONG);  
;   Assembler register usage: library = OpenLibrary(libName, version)
;                               D0                    A1       D0   
;   Input clarifications: NA
;   Struct details of interest: NA 
;   Results: library - a library pointer for a successful open, else zero
;   Further details: http://amigadev.elowar.com/read/ADCD_2.1/Includes_and_Autodocs_2._guide/node0367.html	
	jsr	_LVOOpenLibrary(a6)

	move.l	d0,SP_IntBase(sp)

; CLI ou WORKBENCH?
; CLI or WORKBENCH?
; ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	clr.l	SP_WSegment(sp)
	clr.l	SP_Message(sp)
	clr.l	SP_AutoLock(sp)
	clr.l	SP_DefSize(sp)
	clr.w	SP_AutoName(sp)
	clr.w	SP_Config(sp)
	clr.l	SP_CommandLine(sp)
	move.b	#1,SP_WBench(sp)

; Workbench?
; ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	sub.l	a1,a1
	move.l	SP_ExecBase(sp),a6

; _LVOFindTask()
;   Library name: FindTask 
;   Short description: Find a task with the given name or find oneself
;   C-declaration: struct Task *FindTask(STRPTR);   
;   Assembler register usage: task = FindTask(name)
;                              D0              A1    
;   Input clarifications: NA
;   Struct details of interest: From struct Process
;                               ...
;                               BPTR    pr_CLI;		/* pointer to CommandLineInterface	    */ 
;                               ...
;								Structure Offsets: http://amigadev.elowar.com/read/ADCD_2.1/Includes_and_Autodocs_2._guide/node0551.html	
;                               ... 
;								$00ac   172  pr_CLI
;                               ...
;   Results: task - pointer to the task (or Process)
;
;            Struct Task details: http://amigadev.elowar.com/read/ADCD_2.1/Includes_and_Autodocs_2._guide/node008E.html#line25
;            Struct Process details: http://amigadev.elowar.com/read/ADCD_2.1/Includes_and_Autodocs_2._guide/node0078.html#line38
;
;            In this use case a struct Process reference will be returned
;
;   Further details: http://amigadev.elowar.com/read/ADCD_2.1/Includes_and_Autodocs_2._guide/node0352.html	
	jsr	_LVOFindTask(a6)

	move.l	d0,a0
	tst.l	pr_CLI(a0)
	bne.s	FromCLI             

; Recupere le message
; Retrieve the message
; ~~~~~~~~~~~~~~~~~~~
	move.l	SP_ExecBase(sp),a6
	lea	$5c(a0),a0
	move.l	a0,-(sp)

; _LVOWaitPort()
;   Library name: WaitPort 
;   Short description: Wait for a given port to be non-empty
;   C-declaration: struct Message *WaitPort(struct MsgPort *);   
;   Assembler register usage: message = WaitPort(port)
;                               D0                A0    
;   Input clarifications: port - a pointer to the message port
;   Struct details of interest: NA 
;   Results: message - a pointer to the first available message
;   Further details: http://amigadev.elowar.com/read/ADCD_2.1/Includes_and_Autodocs_2._guide/node038C.html	
	jsr	_LVOWaitPort(a6)		

	move.l	(sp)+,a0

; _LVOGetMsg()
;   Library name: GetMsg 
;   Short description: Get next message from a message port
;   C-declaration: struct Message *GetMsg(struct MsgPort *);   
;   Assembler register usage: message = GetMsg(port)
;                               D0              A0    
;   Input clarifications: port - a pointer to the receiver message port
;   Struct details of interest: NA 
;   Results: message - a pointer to the first message available
;   Further details: http://amigadev.elowar.com/read/ADCD_2.1/Includes_and_Autodocs_2._guide/node035A.html 	
	jsr	_LVOGetMsg(a6)	

	move.l 	d0,SP_Message(sp)
	move.l 	d0,a2
	moveq	#-1,d2

; Change le directory >>> directory AMOS
; Change directory >>> AMOS directory
; ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

; Accessing AppMessage field am_ArgList 
;
; a2 points to a AppMessage struct:
;	 struct AppMessage {
;       ...
;	    struct WBArg *am_ArgList;	/* the arguements themselves */
;       ...
;	 };	
;
; Definition of APTR in TYPES.I
;    APTR	    MACRO		; untyped pointer (32 bits - all bits valid)
;    \1	    EQU     SOFFSET
;    SOFFSET     SET     SOFFSET+4
;	        ENDM
;
; Definition of AppMessage in WORKBANCH.I
;    STRUCTURE AppMessage,0
;    ...
;    APTR am_ArgList			; the arguments themselves
;    ...
; 
; Offset to start of am_ArgList address
;    ...
;  ! $0022    34  am_ArgList    We target this property
;    $0026    38  am_Version
;    ...
;
; AppMessage details: http://amigadev.elowar.com/read/ADCD_2.1/Includes_and_Autodocs_2._guide/node0135.html#line125    
;
; Note: Incorrect hard coded offset for am_ArgList was being used
;    $24(a2)
;    $24 -> #36  
;    See: http://obligement.free.fr/articles/assembleur_copie_icone.php

	move.l	am_ArgList(a2),d0

; If no argument list jump to .PaLock
	beq.s	.PaLock

; Accessing struct WBArg
;    struct WBArg {
; 	    BPTR		wa_Lock;	/* a lock descriptor */
; 	    BYTE *		wa_Name;	/* a string relative to that lock */
;    };
;
; Definition of BPTR in DOS.I
;    * Macro to indicate BCPL pointers
;    BPTR	 MACRO			    * Long word pointer
;	     LONG	  \1
;	     ENDM
;
; Definition of WBArg in STARTUP.I
;	STRUCTURE WBArg,0
;	BPTR	wa_Lock			; a lock descriptor
;   ...
;
; WBArg details: http://amigadev.elowar.com/read/ADCD_2.1/Includes_and_Autodocs_2._guide/node0134.html#line35
	
	move.l	d0,a0
	move.l	(a0),d2

; If wa_Lock is 0 jump to .PaLock 
;    A value of zero is still a valid lock. A 0 lock represents the
;    root of file system that you booted from.

	beq.s	.PaLock

; Set a lock on the startup directory 	

	move.l	d2,d1
	move.l	SP_DosBase(sp),a6

; _LVOCurrentDir()
;   Library name: CurrentDir 
;   Short description: Make a directory lock the current directory 
;   C-declaration: BPTR CurrentDir(BPTR)
;   Assembler register usage: oldLock = CurrentDir(lock)
;                                D0                 D1
;   Input clarifications: lock - BCPL pointer to a lock
;   Struct details of interest: NA 
;   Results: oldLock - BCPL pointer to a lock
;   Further details: http://amigadev.elowar.com/read/ADCD_2.1/Includes_and_Autodocs_2._guide/node028F.html
	jsr	_LVOCurrentDir(a6)

.PaLock

; Un programme � charger?
; A program to load?
; ~~~~~~~~~~~~~~~~~~~~~~~
	cmp.l	#2,$1c(a2)
	bne.s	.PaAuto
	move.l	$24(a2),d0
	beq.s	.PaAuto
	move.l	d0,a2
	move.l	8(a2),SP_AutoLock(sp)
	move.l	12(a2),d0
	beq.s	.PaAuto
	move.l	d0,a0
	lea	SP_AutoName(sp),a1
.Cop	move.b	(a0)+,(a1)+
	bne.s	.Cop
	tst.l	d2
	bne.s	.PaAuto
	move.l	SP_AutoLock(sp),d1
	beq.s	.PaAuto
	move.l	SP_DosBase(sp),a6
	jsr	_LVOCurrentDir(a6)
.PaAuto	bra	CommandX

; CLI!
; ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
; SP_Command(sp) contains command line: address (a0), length (d0)   
FromCLI	movem.l	SP_Command(sp),a0/d0
; Branch lower or the same
	cmp.w	#1,d0
; If no command line parameter go to CommandX
	bls	CommandX
; Take the base address from a0
; Add the signed 16-bit value from the lower word of d0
; Subtract 1 (equivalent to adding -1)	
	clr.b	-1(a0,d0.w)

; Explore la ligne de commande
; Explore the command line
; ~~~~~~~~~~~~~~~~~~~~~~~~~~~~
; Saute le d�but
; Skip the beginning
.Cli0	
; Take next byte value and post increment buffer pointer
    move.b	(a0)+,d0
; When we hit byte value of 0 jump to CommandX
	beq	CommandX
; Skip spaces 
	cmp.b	#" ",d0
	beq.s	.Cli0
; Found "-" there are only options 
	cmp.b	#"-",d0
	beq.s	.CliO
; Nom du programme � charger?
; Name of the program to load?
; Adjust one to many increment
	subq.l	#1,a0
; Assign name buffer start address
	lea	SP_AutoName(sp),a1
; Use subroutine .CliNom to get name
	bsr	.CliNom
	
; Skip spaces
.Spc	
    cmp.b	#" ",(a0)+		Stocke le debut command line / Stores the beginning of the command line
	beq.s	.Spc
	
; Adjust one to many increment
	subq.l	#1,a0
	
; Adjust SP_CommandLine to new start point
	move.l	a0,SP_CommandLine(sp)
	bra	CommandX
	
; Options
.CliO	
; Take next byte value and post increment buffer pointer
    move.b	(a0)+,d0
; If no more valid byte values Panic
	beq	.CliE
	
; If the byte value in d0 is less than 'a', the Carry flag will be set
	cmp.b	#"a",d0
; Branch if Carry Set
	bcs.s	.PAm
	
; If the byte value in d0 is greater than 'z', the Carry flag will be 
; clear, and the Zero flag will be clear
	cmp.b	#"z",d0
; Branch if Higher (Carry flag is clear and the Zero flag is clear)
	bhi.s	.PAm
	
; Convert lowercase character to its uppercase equivalent
	sub.b	#$20,d0
	
; Here we have a character between 'a' and 'z' in uppercase	
.PAm	

; Option -C ...
    cmp.b	#"C",d0
	beq	.ClioC
	
; Option -W ...	
	cmp.b	#"W",d0
	beq	.ClioW
	
; Erreur dans la command line
; Error in the command line
; ~~~~~~~~~~~~~~~~~~~~~~~~~~~
.CliE	
    move.l	#Panic_Command,Panic
	bra	Boot_Fatal
	
; Option -C "fichier config"
; Option -C "config file"
; ~~~~~~~~~~~~~~~~~~~~~~~~~~
.ClioC	
	lea	SP_Config(sp),a1
	bsr	.CliNom
	bra.s	.Cli0
	
; Option -W "workbench"
; ~~~~~~~~~~~~~~~~~~~~~
.ClioW	
    clr.b	SP_WBench(sp)
	bra.s	.Cli0
	
; Prend un nom dans la command line
; Takes a name from the command line
; ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
.CliNom	
    move.b	#" ",d1
	move.b	(a0),d0
	
; Exit if end (null termination)
	beq.s	.Clin1
	
; Is character '"'
	cmp.b	#'"',d0
	beq.s	.ClinB
; Is character "'"
	cmp.b	#"'",d0
	bne.s	.Clin0
	
; If '"' found we branch to here 
.ClinB	

; Store end marker
    move.b	d0,d1
	
; Next character
	addq.l	#1,a0

; If "'" not found we branch to here 
.Clin0	
    move.b	(a0),d0

; Exit if end of command line (null termination)
	beq.s	.Clin1
	
; Next character
	addq.l	#1,a0
	
; Check if end marker found 
	cmp.b	d0,d1
	beq.s	.Clin1
	
; Store character
	move.b	d0,(a1)+
	
; Loop for more
	bra.s	.Clin0
	
; On loop end null terminate	
.Clin1	clr.b	(a1)
	rts
	
; Fin de l'exploration des commandes
; End of command exploration
; ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

; For now this is a place holder and exit will be used
CommandX







; ADDED START: Say hello
	move.l  SP_DosBase(sp),a6      ;DOS Library pointer to a6

; _LVOOutput()
;   Library name: Output 
;   Short description: Identify the program's initial output file handle
;   C-declaration: BPTR Output(void) 
;   Assembler register usage: file = Output()
;                              D0      
;   Input clarifications: NA
;   Struct details of interest: NA 
;   Results: file - BCPL pointer to a file handle
;   Further details: http://amigadev.elowar.com/read/ADCD_2.1/Includes_and_Autodocs_2._guide/node02D8.html
	jsr _LVOOutput(a6)  	       ;get output handle

    move.l  d0,d1                  ;move output handle to d1
    lea     msg,a0                 ;text-string address to a0
	move.l  a0,d2                  ;text pointer to d2
	moveq   #35,d3                 ;text length to d3

; _LVOWrite()
;   Library name: Write 
;   Short description: Write bytes of data to a file
;   C-declaration: LONG Write (BPTR, void *, LONG) 
;   Assembler register usage: returnedLength =  Write( file, buffer, length )
;                                    D0                  D1    D2      D3    
;   Input clarifications:
;      file - BCPL pointer to a file handle
;      buffer - pointer to the buffer
;      length - integer
;   Struct details of interest: NA 
;   Results: returnedLength - integer
;   Further details: http://amigadev.elowar.com/read/ADCD_2.1/Includes_and_Autodocs_2._guide/node0310.html	
	jsr     _LVOWrite(a6)          ;write to output

; ADDED END






; ADDED START: Artificial exit

added_exit 

;close librairies

    move.l	SP_ExecBase(sp),a6     ;use exec libraries
    move.l	SP_DosBase(sp),d0      ;DOS library loaded?
	beq.s   skip_dos_close         ;skip close if DOS not open
    movea.l d0,a1                  ;lib base into a1

; _LVOCloseLibrary()
;   Library name: CloseLibrary 
;   Short description: Conclude access to a library
;   C-declaration: void CloseLibrary(struct Library *);
;   Assembler register usage: CloseLibrary(library)
;                                            A1
;   Input clarifications: library - pointer to a library node
;   Struct details of interest: NA 
;   Results: NA
;   Further details: http://amigadev.elowar.com/read/ADCD_2.1/Includes_and_Autodocs_2._guide/node0340.html
	jsr     _LVOCloseLibrary(a6)   ;close DOS

skip_dos_close

    move.l  SP_IntBase(sp),d0      ;intuition library loaded?
	beq.s   skip_int_close         ;skip if intuition not open
	movea.l d0,a1                  ;lib base into a1

; _LVOCloseLibrary()
;   Library name: CloseLibrary 
;   Short description: Conclude access to a library
;   C-declaration: void CloseLibrary(struct Library *);
;   Assembler register usage: CloseLibrary(library)
;                                            A1
;   Input clarifications: library - pointer to a library node
;   Struct details of interest: NA 
;   Results: NA
;   Further details: http://amigadev.elowar.com/read/ADCD_2.1/Includes_and_Autodocs_2._guide/node0340.html	
	jsr     _LVOCloseLibrary(a6)   ;close intuition

skip_int_close

    moveq.l   #0,d0                ;return code
    movea.l SaveSp,a7              ;Restore stack pointer
    rts 

; ADDED END


; Erreur avec datazone non r�serv�e
; Error with unreserved datazone
; ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Boot_Fatal
; Libere amos.library s'il faut
; Free amos.library if necessary
; Prepare DOS base
	move.l	SP_DosBase(sp),a6
; Setup segment data	
	move.l	SP_WSegment(sp),d1
; If no segment reserved do not execute UnLoadSeg()
	beq.s	.Skip


; _LVOUnLoadSeg()
;   Library name: UnLoadSeg 
;   Short description: Unload a seglist previously loaded by LoadSeg()
;   C-declaration: BOOL UnLoadSeg(BPTR)
;   Assembler register usage: success = UnLoadSeg(seglist)
;                               D0                   D1
;   Input clarifications: seglist - BCPL pointer to a segment identifier
;   Struct details of interest: NA 
;   Results: Is broken see details
;   Further details: http://amigadev.elowar.com/read/ADCD_2.1/Includes_and_Autodocs_2._guide/node0306.html 	
	jsr	_LVOUnLoadSeg(a6)
	
; Affiche le message d'erreur
; Show error message
.Skip	
; Prepare library bases
    move.l	SP_DosBase(sp),a3
	move.l	SP_IntBase(sp),a4
; Prepare message 	
	move.l	SP_Message(sp),d7
	
	jsr	Panic_Message      
		
; Ferme DOS / INTUITION
; Close DOS / INTUITION

    move.l	SP_ExecBase(sp),a6
	move.l	SP_DosBase(sp),a1

; _LVOCloseLibrary()
;   Library name: CloseLibrary 
;   Short description: Conclude access to a library
;   C-declaration: void CloseLibrary(struct Library *);
;   Assembler register usage: CloseLibrary(library)
;                                            A1
;   Input clarifications: library - pointer to a library node
;   Struct details of interest: NA 
;   Results: NA
;   Further details: http://amigadev.elowar.com/read/ADCD_2.1/Includes_and_Autodocs_2._guide/node0340.html		
	jsr	_LVOCloseLibrary(a6)

	move.l	SP_IntBase(sp),a1

; _LVOCloseLibrary()
;   Library name: CloseLibrary 
;   Short description: Conclude access to a library
;   C-declaration: void CloseLibrary(struct Library *);
;   Assembler register usage: CloseLibrary(library)
;                                            A1
;   Input clarifications: library - pointer to a library node
;   Struct details of interest: NA 
;   Results: NA
;   Further details: http://amigadev.elowar.com/read/ADCD_2.1/Includes_and_Autodocs_2._guide/node0340.html		
	jsr	_LVOCloseLibrary(a6)

; On peut maintenant sortir!
; Now we can go out! 

	move.l	SP_Message(sp),d7

; Va a la sortie generale!
; Go to the general exit!
	jmp	Get_Out       

;		Data initialisation
; ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
IntName:	dc.b 	"intuition.library",0
		even
		
;		Messages d'erreur d'alerte
;         Alert error messages
; ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Panic_Command	dc.b	"Bad command line.",0
		even
		
