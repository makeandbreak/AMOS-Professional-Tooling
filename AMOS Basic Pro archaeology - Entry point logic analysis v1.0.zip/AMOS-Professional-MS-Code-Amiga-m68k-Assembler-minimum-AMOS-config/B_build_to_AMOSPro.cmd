del out\AMOSPro.lst
del out\AMOSPro
tools\vasmm68k_mot -devpac -nocase -w -Fhunkexe -L out\AMOSPro.lst  -o out\AMOSPro +B.s